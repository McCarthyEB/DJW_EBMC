list = [2,3,-1,12]
ind = -2

if ind in list:
   print("%d is in list " % ind, list)

if ind not in list:
   print("%d is not in list " % ind, list)
