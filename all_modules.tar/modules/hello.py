#
# A test definition file for the slab package
#
import sys
#
def hello(name):
   print("Hello %s, welcome to the slab package" % name)
